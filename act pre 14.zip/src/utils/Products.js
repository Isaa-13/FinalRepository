export const products = [
    {
        id: 1,
        name: 'Huawei Freebuds 3 Pro ',
        price: 2753 ,
        description: 'Doble driver con sonido potente. Llamadas claras. ANC Inteligente 3.0.',
        image: '../../public/Huawei_Freebuds_3_pro.jpg'
    },
    {
        id: 2,
        name: 'Samsung Galaxy Buds 3 Pro',
        price: 3552 ,
        description: 'Diseño ergonómico para un sonido supremo. Cuenta con Galaxy AI. Sonido Ultra-High-Quality.',
        image: '../../public/Samsung_Galaxy_Buds_3_Pro.jpg'
    },
    {
        id: 3,
        name: 'Sony WF-1000XM4',
        price: 6799 ,
        description: 'Noise cancelling avanzado y la calidad de sonido a otro nivel. Adaptables a tu entorno.',
        image: '../../public/Sony_WF-1000XM4,jpeg'
    },
    {
        id: 4,
        name: 'Apple Airpods 2 pro ',
        price: 4360 ,
        description: 'Audio adaptativo a tu nivel. Audio espacial personalizado. con chip  H2 de última generación.',
        image: '../../public/Airpods-pro-2.png'
    },

    {   id: 5,
        name: "Bocína inalámbrica SONY XB100" ,
        price: 984 , 
        description: "Sonido nítido y abrasador", 
        image: '../../public/Airpods-pro-2.png'

    },
    {   id: 6,
        name: "Audífonos Over Ear SkullCandy Hesh" ,
        price: 1200 + "MXN" , 
        description: "Con 22h de autonomía", 
        image: '../../public/Airpods-pro-2.png'

    }
]