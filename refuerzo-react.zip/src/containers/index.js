export {default as AboutUsPage} from "./AboutUsPage/AboutUsPage";
export {default as HomePage} from "./Homepage/App";
export {default as Acercade} from "./Acercade/Acercade";